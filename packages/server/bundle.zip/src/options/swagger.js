module.exports = {
    pathPrefixSize: 2,
    basePath: '/',
    info: {
        title: 'DHIS-2 App Store API Documentation',
        description: '.',
    },
    /*pathReplacements: [
        {
            replaceIn: 'all',
            pattern: /v([0-9]+)\//,
            replacement: ''
        }
    ],*/
    deReference: false,
    jsonEditor: true,
}
