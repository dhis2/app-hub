module.exports = {
    swaggerOptions: require('./swagger'),
}
